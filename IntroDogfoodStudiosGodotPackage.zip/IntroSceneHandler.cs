using Godot;
using System;

public partial class IntroSceneHandler : Node2D
{
    [ExportCategory("Intro Setup")]
    [Export] private double introTime = 2;
    [Export] private string gameSceneName = "res://GameScene.tscn";

    private double timeLeft;

    public override void _Ready()
    {
        timeLeft = introTime;
    }

    public override void _Process(double delta)
    {
        timeLeft -= delta;

        if (timeLeft <= 0)
        {
            GetTree().ChangeSceneToFile(gameSceneName);
        }
    }
}
